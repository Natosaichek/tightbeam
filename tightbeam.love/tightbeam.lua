function love.draw()
	love.graphics.pring("hello world", 400,300)
end