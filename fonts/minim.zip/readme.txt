minim is an open source font designed to simplify and remove the superfluous. Doing more with less. Designed by Raul Montala

How to install:

Linux: Download minim.zip, extract the file, from Terminal copy the font to the default directory with the following command: sudo cp minim.otf /usr/share/fonts/truetype.
OSX: Download minim.zip, extract the file, open the file minim.otf or minim.ttf > Click to Install font.
Windows: Download minim.zip, extract the file, open the file minim.otf or minim.ttf > Click to Install.